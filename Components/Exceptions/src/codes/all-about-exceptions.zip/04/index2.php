<?php

class ValidationException extends Exception
{

}

throw new ValidationException('Data was invalid');
