<?php

class CustomException extends Exception
{

}

throw new CustomException();
