<?php

class ValidationException extends Exception
{

}

throw new ValidationException('Data is invalid');
