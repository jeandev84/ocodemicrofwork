<?php

namespace App\Exceptions;

class MethodNotAllowedException extends \Exception
{
    //
}
