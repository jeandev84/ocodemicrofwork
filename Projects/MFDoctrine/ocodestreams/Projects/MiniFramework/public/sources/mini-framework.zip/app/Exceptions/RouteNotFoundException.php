<?php

namespace App\Exceptions;

class RouteNotFoundException extends \Exception
{
    //
}
