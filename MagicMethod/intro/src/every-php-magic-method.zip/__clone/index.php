<?php

class User
{

}

$user = new User();

var_dump($user);
var_dump($user);