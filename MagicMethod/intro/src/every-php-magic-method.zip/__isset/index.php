<?php

$name = 'Alex';

var_dump(isset($name));