<?php

class SomeClass
{

}

$class = new SomeClass();
$class->name = 'Alex';

var_dump($class);