<?php return Config::__set_state(array(
   'config' => 
  array (
    'db_name' => 'app',
  ),
));