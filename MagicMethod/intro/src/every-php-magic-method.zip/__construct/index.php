<?php

class SomeClass
{
    public function __construct()
    {
        var_dump('Run');
    }
}

$class = new SomeClass();
