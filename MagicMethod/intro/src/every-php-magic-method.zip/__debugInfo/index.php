<?php

class User
{
    protected $name = 'Alex';
}

$user = new User();

var_dump($user);