<?php

namespace App\Config\Loaders;

interface Loader
{
    public function parse();
}
