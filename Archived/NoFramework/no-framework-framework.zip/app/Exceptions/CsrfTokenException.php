<?php

namespace App\Exceptions;

use Exception;

class CsrfTokenException extends Exception
{
   
}