<?php

namespace App\Controllers;

use Interop\Container\ContainerInterface;

abstract class Controller
{
    //
}
