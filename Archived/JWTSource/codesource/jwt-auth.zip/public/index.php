<?php

require_once __DIR__ . '/../bootstrap/app.php';

$app->run();
